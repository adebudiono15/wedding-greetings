<?php return array (
  'counter' => 'App\\Http\\Livewire\\Counter',
  'ucapan' => 'App\\Http\\Livewire\\Ucapan',
);