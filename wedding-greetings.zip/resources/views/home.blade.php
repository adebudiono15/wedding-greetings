@extends('layouts.app')

@section('content')
<div class="container">
    <livewire:ucapan></livewire:ucapan>
</div>
@endsection
